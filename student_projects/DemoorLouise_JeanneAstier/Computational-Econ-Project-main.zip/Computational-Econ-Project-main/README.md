## Description of the project

This project was built in the context of the course "Advanced Methods in Computational Economics" taught by Simon Scheidegger in November 2022 as part of our Master program at ENSAE Paris. Our aim is to apply the Deep Equilibrium Nets method to solve an Overlapping Generations Model integrating an Environmental concern. 

## Repository organization

This repository gathers the delivrable of this project: 
- report.pdf contains a short write-up describing the model we solve and the main results from this project
- the literature folder contains the main articles which were used 
- the code folder contains the code on which the presented results are based
  - OLG_first_model_without_shocks.ipynb solves a first reduced-form model
  - OLG_first_model_with_shocks_envi.ipynb solves an extension of the model integrating exogenous shocks
  - OLG_first_model_without_shocks_new_euler.ipynb solves the complete model 
  
  
